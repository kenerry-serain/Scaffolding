﻿using $DomainCoreModelsNamespace$;

namespace $DomainEntitiesNamespace$
{
    public class $Entity$ : Entity
    {
        public string Name { get; set; }
    }
}
