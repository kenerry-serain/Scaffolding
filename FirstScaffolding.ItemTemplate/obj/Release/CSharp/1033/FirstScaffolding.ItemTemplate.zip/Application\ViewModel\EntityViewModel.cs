﻿namespace $ApplicationViewModelsNamespace$
{
    public class $Entity$ViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
